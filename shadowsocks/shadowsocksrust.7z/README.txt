1.双击start.vbe启动

2.也可以在该文件夹创建start.vbe的快捷方式，然后将快捷方式放到启动文件夹

 （win+r输入shell:startup 打开启动文件夹）



3.使用get-acl.bat获取最新的gfwlist.acl文件